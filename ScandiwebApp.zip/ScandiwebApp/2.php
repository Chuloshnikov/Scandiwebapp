<?php

print_r($_GET);