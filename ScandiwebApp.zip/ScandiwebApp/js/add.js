'use strict'

document.getElementById('productType').addEventListener('change', function(){
    let isDvd = this.options[this.selectedIndex].classList.contains("DVD");
    let isBook = this.options[this.selectedIndex].classList.contains("Book");
    let isFurniture = this.options[this.selectedIndex].classList.contains("Furniture");
    document.querySelector('.switcher-dvd').style.display = isDvd ? "block" : "none";
    document.querySelector('.switcher-book').style.display = isBook ? "block" : "none";
    document.querySelector('.switcher-furniture').style.display = isFurniture ? "block" : "none";
  });