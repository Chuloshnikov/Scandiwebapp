'use strict'

/*document.getElementById('delete-product-btn').onclick = function () {
    let checkInput = document.querySelectorAll('.delete-checkbox');
    for (let i = 0; i < checkInput.length; i++) {
      let box = checkInput[i];
      if (box.checked === true) {
          box.parentNode.remove(box);
      }
    }   
  }
*/
  /*var selected = [];
  $('form[name=table] input:checkbox:checked').each(function(){
      var checkbox_value = $(this).val();
      selected.push(checkbox_value);
  });
  $.ajax({
  url : 'delete.php',
  type : 'GET',
  data : { check: selected },
  success : function(response) {
      if(response === "ok") {
          $('form[name=table] input:checkbox:checked').each(function(){
               $(this).parent().parent().fadeIn('fast');
          });
      }
  }
  });

