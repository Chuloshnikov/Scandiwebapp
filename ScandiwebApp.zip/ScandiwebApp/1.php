<?php
print_r($_GET['name']);
echo "<pre>";
print_r($_GET);
echo "</pre>";

if(isset($_GET['product_form'])) {
    $skuform = $_GET['sku'];
    $nameform = $_GET['name'];
    $priceform = $_GET['price'];
    $productTypeform = $_GET['productType'];
    $mysqli = new mysqli("localhost", "root", "", "products");
    if ($mysqli->connect_errno) {
        echo "Sorry, there was a problem with the connection.";
        exit;
    }
    $sku = '"' . $mysqli->cubrid_real_escape_string($skuform).'"';
    $name = '"' . $mysqli->cubrid_real_escape_string($nameform).'"';
    $price = '"' . $mysqli->cubrid_real_escape_string($priceform).'"';
    $productType = '"' . $mysqli->cubrid_real_escape_string($productTypeform).'"';
    if ($productType == 'DVD') {
    $dvd = $productType; 
    $query = "INSERT INTO DVD (sku, name, price) VALUES ($sku, $name, $price)";
    $result = mysqli->query($query);
    if($result) {
        print('Successfully!'. '<br>');
    }
    $mysqli->close();
    } else if ($productType == 'Book'){
        $book = $productType; 
    $query = "INSERT INTO Book (sku, name, price) VALUES ($sku, $name, $price)";
    $result = mysqli->query($query);
    if($result) {
        print('Successfully!'. '<br>');
    }
    $mysqli->close();
    } else if ($productType == 'Furniture') {
        $furniture = $productType; 
        $query = "INSERT INTO Furniture (sku, name, price) VALUES ($sku, $name, $price)";
        $result = mysqli->query($query);
        if($result) {
            print('Successfully!'. '<br>');
        }
        $mysqli->close();
    }
}
?>


<span class="checkbox-column"><input class="delete-checkbox" type="checkbox" name="product"><p>JVC200123 <br>Acme DISC <br>1.00$ <br>Size: 700 MB</p></span>
<span class="checkbox-column"><input class="delete-checkbox" type="checkbox" name="product"><p>GGWP0007 <br>Balad of the Scroughs <br>20.00$ <br>Weight: 2KG</p></span>
<span class="checkbox-column"><input class="delete-checkbox" type="checkbox" name="product"><p>TR120555 <br>Chair <br>40.00$ <br>Dimension 24x45x15</p></span>




document.getElementById('delete-product-btn').onclick = function () {
  let checkInput = document.querySelectorAll('.delete-checkbox');
  for (let i = 0; i < checkInput.length; i++) {
    let box = checkInput[i];
    if (box.checked === true) {
        box.parentNode.remove(box);
    }
  }   
}
